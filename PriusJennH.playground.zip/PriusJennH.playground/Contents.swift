//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
    
var carColor = ["Magnetic Gray Metallic", "Titanium Glow","Classic Silver Metallic","Blizzard Pearl","Hypersonic Red","Blue Magnetism"]

var carModel = ["Plus","Premium","Advanced"]

var carInterior = ["Moonstone Fabric", "Black Fabric"]

var carAccessories = ["10-Spoke Alloy Wheels","Aero Side Splitters","Alloy Wheel Locks","Body Side Molding","Cargo Cross Bars","Door Edge Guards","Rear Bumper Applique","Cargo Tote","Carpet Cargo Mat","Carpet Floor Mat","Emergency Kit","First Aid Kit","Security System","Universal Table Holder","Carpet Mat Package","Protection Package","Prime Accessory Package"]

class Prius {
    var color: String = ""
    var model: String = ""
    var interior: String = ""
    var accessory1: String = ""
    var accessory2: String = ""
    var accessory3: String = ""
    
    func yourCar() -> String {
        return "Your Prius is a \(self.color) \(self.model) with \(self.interior) and \(self.accessory1), \(self.accessory2), and \(self.accessory3)."
    }
    
    
}

var car = Prius()

let randColor = arc4random_uniform(5)
car.color = carColor[Int(randColor)]
print(car.color)

let randModel = arc4random_uniform(2)
car.model = carModel[Int(randModel)]
print(car.model)

let randInterior = arc4random_uniform(1)
car.interior = carInterior[Int(randInterior)]
print(car.interior)

var randAccessory1 = arc4random_uniform(16)
car.accessory1 = carAccessories[Int(randAccessory1)]
print(car.accessory1)

var randAccessory2 = arc4random_uniform(16)
while randAccessory1 == randAccessory2{
    randAccessory2 = arc4random_uniform(16)}
    car.accessory2 = carAccessories[Int(randAccessory2)]
print(car.accessory2)

var randAccessory3 = arc4random_uniform(16)
while randAccessory1 == randAccessory3 || randAccessory2==randAccessory3{
    randAccessory3 = arc4random_uniform(16)}
    car.accessory3 = carAccessories[Int(randAccessory3)]
print(car.accessory3)

car.yourCar()